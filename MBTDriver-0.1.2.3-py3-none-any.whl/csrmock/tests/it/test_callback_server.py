import requests

from csrmock.core.callback_server import CallBackServer
from mtf.core.logger import log
from mtf.core.utils import Utils


class TestHook:
    def setup_class(self):
        pass

    def test_hook(self):
        r = requests.post(
            'http://127.0.0.1:8008/hook',
            json={
                'req': '1',
                'config': {
                    'action': [
                        {
                            'time.sleep': 3
                        },
                        {
                            'eval': '1+1'
                        }
                    ]
                }
            }
        )
        log.debug(r.text)
        log.debug(r.json())
        assert r.json()['data'] == 2
