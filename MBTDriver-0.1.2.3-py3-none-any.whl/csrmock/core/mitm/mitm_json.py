"""HTTP-specific events."""
import sys
import threading
from time import time

import mitmproxy.http
from mitmproxy.tools.main import mitmdump

from csrmock.core.mock_server import MockServer
from mtf.core.logger import log as log2
from mtf.core.singleton import Singleton
from mtf.core.utils import Utils


@Singleton
class MitmJson:

    def __init__(self):
        self.mock_server = MockServer()
        self.mock_server.set_protocol('json')

    def handle_mock(self, flow: mitmproxy.http.HTTPFlow):
        flow.response = self.mock_server.mock(flow.request, flow.response)
        req_body = flow.request.content
        if req_body:
            req_body = Utils.to_json_object(req_body.decode('utf-8'))
        else:
            req_body = None

        res_body = flow.response.content
        if res_body:
            res_body = Utils.to_json_object(res_body.decode('utf-8'))
        else:
            res_body = None

        self.mock_server.history.append({
            'req': {
                'timestamp': int(time()),
                'content': req_body,
                'data': flow.request.data,
            },
            'res': {
                'timestamp': int(time()),
                'content': res_body,
                'data': flow.response.data,
            }
        })

    def http_connect(self, flow: mitmproxy.http.HTTPFlow):
        """
            An HTTP CONNECT request was received. Setting a non 2xx response on
            the flow will return the response to the client abort the
            connection. CONNECT requests and responses do not generate the usual
            HTTP handler events. CONNECT requests are only valid in regular and
            upstream proxy modes.
        """

    def requestheaders(self, flow: mitmproxy.http.HTTPFlow):
        """
            HTTP request headers were successfully read. At this point, the body
            is empty.
        """

    def request(self, flow: mitmproxy.http.HTTPFlow):
        """
            The full HTTP request has been read.
        """
        # self.handle_mock(flow)

    def responseheaders(self, flow: mitmproxy.http.HTTPFlow):
        """
            HTTP response headers were successfully read. At this point, the body
            is empty.
        """

    def response(self, flow: mitmproxy.http.HTTPFlow):
        """
            The full HTTP response has been read.
        """
        self.handle_mock(flow)

    def error(self, flow: mitmproxy.http.HTTPFlow):
        """
            An HTTP error has occurred, e.g. invalid server responses, or
            interrupted connections. This is distinct from a valid server HTTP
            error response, which is simply a response with an HTTP error code.
        """
        # self.handle_mock(flow)

    @classmethod
    def main(cls, listen=8001, host='ceshiren.com', port=80):
        log2.debug(f'startup timestamp {time()} {threading.current_thread().name} {threading.current_thread().ident}')
        sys.argv = [
            __file__,
            "-p", str(listen),
            "-m", f'reverse:http://{host}:{port}',
            "-s", __file__
        ]

        from csrmock.core.callback_server import CallBackServer

        callback_json = CallBackServer()
        Utils.thread(
            target=callback_json.start_server,
            args=(8002,),
            name="callback_json",
        )

        # 官方要求必须主线程

        mitmdump()

        # dump=threading.Thread(
        #     target=mitmdump,
        #     name='dump'
        # )
        # dump.start()


addons = [
    MitmJson()
]
if __name__ == '__main__':
    MitmJson.main()
