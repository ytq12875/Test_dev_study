from mtf.core.data_dynamic import DataDynamic


def test_cartesian():
    data = list(DataDynamic.cartesian([1, 2, 3], ['a', 'b', 'c'], ['m', 'n']))
    print(data)
    assert len(data) == 18


def test_data_gen():
    d = {
        'a': [1, 2],
        'b': [10, 20, 30, 40]
    }
    r = DataDynamic.data_gen(d)
    print(r)


def test_filter():
    data = list(DataDynamic.cartesian([1, 2, 3], ['a', 'b', 'c'], ['m', 'n']))
    data2 = list(DataDynamic.filter(data, lambda x: x[2] == 'n'))
    assert len(data2) == len(data) / 2


def test_middle():
    print(DataDynamic.middle(f1=[1, 2, 3], f2=[4, 5, 6], f3=['a', 'b', 'c', 'd', 'e']))
