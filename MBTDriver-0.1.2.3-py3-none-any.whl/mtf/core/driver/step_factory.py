from mtf.core.driver.appium_step import AppiumStep
from mtf.core.driver.requests_step import RequestsStep
from mtf.core.driver.selenium_step import SeleniumStep
from mtf.core.step import Step


class StepFactory:
    @classmethod
    def get_step(cls, step: Step, context_current):
        if context_current == 'selenium':
            step_new = SeleniumStep(step.get_dict())
        elif context_current == 'appium':
            step_new = AppiumStep(step.get_dict())
        elif context_current == 'requests':
            step_new = RequestsStep(step.get_dict())
        else:
            step_new = step
        return step_new

    @classmethod
    def get_context_by_step(cls, step: Step):
        if 'selenium' in step.keys():
            return 'selenium'
        elif 'appium' in step.keys():
            return "appium"
        elif 'requests' in step.keys():
            return "requests"
        else:
            return None
