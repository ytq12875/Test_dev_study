import itertools
from functools import reduce
from math import floor


class DataDynamic:
    @classmethod
    def cartesian(self, *args):
        return itertools.product(*args)

    @classmethod
    def data_gen(self, data, model=0):
        # todo: 路径遍历
        # todo：all pair
        # https://docs.python.org/zh-cn/3/library/itertools.html

        # 正交法
        # params:
        #   a: [1, 2]
        #   b: [3, 4]
        res = []
        if isinstance(data, dict):
            # 简单的配对，是正交的特例
            if model == 0:
                # 取出最大的长度
                size_max = max([len(v) for v in data.values() if isinstance(v, list)])
                for index in range(size_max):
                    dict_temp = {}
                    for k in data.keys():
                        size_real = len(data[k])
                        # 如果长度不够匹配其他的数据，那么自动从头开始取，实现了正交数据生成
                        index_k = index % size_real
                        dict_temp[k] = data[k][index_k]
                    res.append(dict_temp)

        # todo：笛卡尔积

        # 固定列表模式
        # params:
        #   - a: 1
        #   - a: 2
        elif isinstance(data, list):
            '''
            支持普通的列表表达式
            params:
              - { a: 1, b: 2 }
              - { a: 3, b: 4 }
            '''
            res = data
        return res

    @classmethod
    def filter(self, data, filter_expr):
        return filter(filter_expr, data)

    @classmethod
    def middle(cls, **kwargs):
        r = []
        for key, value in kwargs.items():
            other = [k for k in kwargs.keys() if key != k]
            for index, v in enumerate(value):
                a = {key: v}
                for k in other:
                    middle = floor((len(kwargs[k]) - 1) / 2)
                    a[k] = kwargs[k][middle]
                r.append(a)
        distinct_func = lambda x, y: x if y in x else x + [y]
        return reduce(distinct_func, [[], ] + r)