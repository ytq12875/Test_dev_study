import itertools
from math import floor


class DataDynamic:
    @classmethod
    def cartesian(self, *args):
        return itertools.product(*args)

    @classmethod
    def filter(self, data, filter_expr):
        return filter(filter_expr, data)

    @classmethod
    def middle(cls, **kwargs):
        r = []
        for key, value in kwargs.items():

            other = [k for k in kwargs.keys() if key != k]

            middle_cur = floor((len(value) - 1) / 2)
            for index, v in enumerate(value):
                if index == middle_cur:
                    continue
                else:
                    a = {key: v}
                    for k in other:
                        middle = floor((len(kwargs[k]) - 1) / 2)
                        a[k] = kwargs[k][middle]

                    r.append(a)

        return r
