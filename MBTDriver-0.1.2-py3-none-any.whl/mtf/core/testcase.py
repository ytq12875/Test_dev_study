from typing import List

from mtf.core.context_base import ContextBase
from mtf.core.logger import log
from mtf.core.step import Step


class TestCase(ContextBase):
    steps: List[Step] = {}
    name = None
    desc = ""

    def __init__(self, steps: List[Step], context):
        self.steps = steps
        self._context = context

    def run_steps(self):
        self.run_setup()

        self.get_context().append_testcase(f'{self.name}')
        self.get_context().steps_exclude = ['setup']
        self.get_context().run_steps(self.steps)
        self.get_context().steps_exclude = None
        self.get_context().append_param_node()

    def run_setup(self):
        log.info("setup begin")
        self.get_context().append_testcase(f'{self.name}')
        self.get_context().steps_include = [
            'if',
            'while', 'exec', 'eval',
            'param', 'params', 'data', 'var',
            'setup'
        ]
        self.get_context().run_steps(self.steps)
        self.get_context().steps_include = None
        log.info("setup end")
        return self.get_context().return_value()
