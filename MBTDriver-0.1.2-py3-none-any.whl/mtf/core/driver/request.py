# Author:Pegasus-Yang
# Time:2020/10/17 15:15
import requests


class Request:
    def __init__(self, base_url=None):
        self.session = requests.Session()
        self.base_url = base_url

    def new_session(self):
        self.session = requests.Session()

    def request(self, method, url='', skip_list=None, **kwargs):
        if not url.startswith('http') and self.base_url:
            url = self.base_url + url
        if skip_list:
            for key, value in skip_list.items():
                if key in kwargs.keys():
                    if isinstance(value, list):
                        for skip_key in value:
                            kwargs[key].pop(skip_key, None)
                    elif isinstance(value, (int, str)):
                        kwargs[key].pop(value, None)
        res = self.session.request(method=method, url=url, **kwargs)
        return res

    def get(self, url='', **kwargs):
        return self.request('get', url=url, **kwargs)

    def post(self, url='', **kwargs):
        return self.request('post', url=url, **kwargs)

    def delete(self, url='', **kwargs):
        return self.request('delete', url=url, **kwargs)

    def put(self, url='', **kwargs):
        return self.request('put', url=url, **kwargs)

    def head(self, url='', **kwargs):
        return self.request('head', url=url, **kwargs)

    def patch(self, url='', **kwargs):
        return self.request('patch', url=url, **kwargs)

    def options(self, url='', **kwargs):
        return self.request('options', url=url, **kwargs)
