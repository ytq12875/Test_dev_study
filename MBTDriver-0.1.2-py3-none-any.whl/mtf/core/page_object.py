from mtf.core.context_base import ContextBase
from mtf.core.logger import log


class PageObject(ContextBase):
    def run_steps(self, name):
        pass

    @classmethod
    def method_gen(cls, name):
        '''
        调用page object方法的时候允许传递dict，充当参数
        - po.sum_demo:
            p1: xx
            p2: xxx
        在sum_demo定义的时候，可以直接使用包括p1 p2在内的各种变量 参数与全局变量
        :param name:
        :return:
        '''

        def _method(self: PageObject, *args, **kwargs):
            self.get_context().global_dict.update(kwargs)
            self.get_context().global_dict['args'] = args
            self.get_context().global_dict['kwargs'] = kwargs
            # todo: 增加参数声明与约束

            steps = self.get_context().store.methods[name]
            return self.get_context().run_steps(steps)

        # 把方法名直接放到类属性里
        setattr(cls, name, _method)
        log.debug(f"create method {name} {_method}")

    @classmethod
    def class_gen(cls, class_name, method_name_list, context=None):
        #生成新类，继承自pageobject
        class_new: PageObject = type(class_name, (PageObject,), dict())
        class_new._context = context
        log.debug(f"create class {class_name} {class_new}")
        for name in method_name_list:
            #生成类的方法
            class_new.method_gen(name)
        return class_new
