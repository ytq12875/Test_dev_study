import pandas


class DataSource:
    @classmethod
    def load(self, file_path, *args, **kwargs):
        file_type = file_path.split('.')[-1]

        if file_type == "xlsx" or file_type == "xls":
            r = pandas.read_excel(file_path, args[0])
        elif file_type == "csv":
            r = pandas.read_csv(file_path)
        else:
            pass

        return r.to_dict(orient='records')
