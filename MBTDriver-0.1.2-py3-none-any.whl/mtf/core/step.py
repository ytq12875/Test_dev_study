import importlib
import inspect
import logging
from typing import Dict

from mtf.core.context_base import ContextBase
from mtf.core.data_treating.text_file import TextFile
from mtf.core.logger import log
from mtf.core.utils import Utils


class Step(ContextBase):

    def __init__(self, dict=None):
        if dict is None:
            dict = {}
        self._dict: Dict = dict
        self._method_name = ""
        self._object_name = ""
        self._package_name = ''
        self._params = None
        self._params_parse = True

        super().__init__()

    def keys(self):
        return self._dict.keys()

    def values(self):
        return self._dict.values()

    def get_key(self, key):
        return self._dict.get(key)

    def get_dict(self):
        return self._dict

    def context(self, name):
        self.get_context().set_context(name)

    def method(self, *args, **kwargs):
        if len(args) > 1:
            log.debug(args)
            if list(args[0].keys())[0] == "name":
                # 方法定义
                name = list(args[0].values())[0]
                self.get_context().store.methods[name] = [Step(s) for s in args[1:]]
                log.debug(f"method {name} added")
            else:
                # 直接执行
                self.get_context().run_steps([Step(arg) for arg in args])
        elif len(args) == 1:
            # 间接调用
            name = args[0]
            log.debug(self.get_context().store.methods.keys())
            self.get_context().run_steps(self.get_context().store.methods[name])

    def _return(self, var_name=None):
        '''
        - assert: $(self._return()==7)
        - return: res
        :param var_name:
        :return:
        '''
        res = self.get_context().return_value()
        if var_name is not None:
            self.data(var_name, res)
            globals()[var_name] = res
        else:
            pass
        return res

    def return_value(self, *args, **kwargs):
        '''
        可以显式指定返回值，也可以获取上一步的返回值
        :param args:
        :param kwargs:
        :return:
        '''
        if len(args) > 0:
            return args[0]
        elif kwargs != {}:
            return kwargs
        else:
            return self.get_context().return_value()

    def return_to(self, var_name=None):
        return self._return(var_name)

    def save(self, var_name=None):
        '''
        return的另外一个名字
        :param var_name:
        :return:
        '''
        return self._return(var_name)

    def to_json(self, o):
        return Utils.to_json_object(o)

    # 已经用不到了，可以自动导入了
    def _import(self, name, *args, **kwargs):
        globals()[name] = importlib.import_module(name, *args, **kwargs)

    def exec(self, *args):
        '''
        通用用于循环
        执行python语句
        :param expr:
        :return:
        '''
        for expr in args:
            exec(expr, self.get_context().global_dict)

    def eval(self, expr):
        '''
        执行python表达式，表达式(a+1)可以返回值，语句(a=a+1 a+=1)无法返回值
        :param expr:
        :return:
        '''

        res = Utils.eval(f'$({expr})', self.get_param_dict())
        # res = eval(expr)
        return res

    def log(self, msg, level=logging.INFO):
        log.log(level=level, msg=msg)

    def log_level(self, level=logging.DEBUG):
        log.setLevel(level)

    # def utils(self):
    #     return Utils

    def load_data(self, *args, **kwargs):
        return Utils.load_data(*args, **kwargs)

    def data(self, *args):
        if len(args) == 1:
            return self.get_context().global_dict[args[0]]
        elif len(args) == 2:
            self.get_context().global_dict[args[0]] = args[1]
            return None
        elif len(args) == 0:
            return self.get_context().global_dict

    def var(self, **kwargs):
        '''
        比data更灵活的变量定义
        - var:
            a: 1
            b: [2,3]
            c: { a: 1, b: 2 }
            d:
              d1: 1
              d2: ddd
        :param kwargs:
        :return:
        '''
        self.get_context().global_dict.update(kwargs)

    def load(self, file_name):
        return Utils.load_yaml(Utils.load(file_name))

    def _while(self, if_while: str, if_true):
        if isinstance(if_while, str) and not if_while.startswith('$'):
            if_while = f'$({if_while})'
        while self.branch_hit(if_while):
            for step in if_true:
                step_object = Step(step)
                self.get_context().run_step(step_object)

    def _if(self, if_if: str, if_true=None, if_false=None):
        if isinstance(if_if, str) and not if_if.startswith('$'):
            if_if = f'$({if_if})'
        if self.branch_hit(if_if):
            self.get_context().add_true(self)
            if if_true is None:
                return
            for step in if_true:
                step_object = Step(step)
                self.get_context().run_step(step_object)

        else:
            self.get_context().add_false(self)
            if if_false is None:
                return
            for step in if_false:
                step_object = Step(step)
                self.get_context().run_step(step_object)

    # todo: 增加if elif
    # def _if(self, if_if, if_elif:None):
    #     #todo
    #     pass

    def setup(self, *args):
        steps = [Step(arg) for arg in args]
        include = self.get_context().steps_include
        exclude = self.get_context().steps_exclude

        # 直接执行setup下的所有指令
        self.get_context().steps_include = None
        self.get_context().steps_exclude = None
        self.get_context().run_steps(steps)
        # 恢复环境
        self.get_context().steps_include = include
        self.get_context().steps_exclude = exclude

    def eq(self, real, expect):
        self._assert(real, expect)

    def _assert(self, real, expect=True):
        '''
        - assert: $(a>=10)
        - assert: true
        - assert: [1, 2]
        - assert:
            real: 1
            expect: 2
        #todo: - assert: "a>=10" == a

        todo: https://www.pythoninsight.com/2018/02/assertion-rewriting-in-pytest-part-4-the-implementation/
        :param real:
        :param expect:
        :return:
        '''
        if isinstance(real, str):
            assert real == str(expect)
        else:
            assert real == expect

    def shell(self, *args):
        return Utils.shell(*args)

    def process(self, target, args=(), kwargs={}):
        # target = MitmTcp.main
        return Utils.process(target=target, args=args, kwargs=kwargs)

    def hold(self, target, args=()):
        # target = MitmTcp.main
        return Utils.thread(target=target, args=args)

    def parse_text(self, *args, **kwargs):
        return TextFile().parse(*args, **kwargs)

    def params(self, *args, **kwargs):
        params_dict = {}
        if kwargs:
            for k, v in kwargs.items():
                if isinstance(v, dict):
                    # - params:
                    #   a: [1, 2, 3]
                    #   b: [2, 2, 2]
                    #   c: [3, 2, 1]
                    #   d:
                    #     range: [100, 106]

                    # todo: 有歧义，用merge代替

                    # 解析字段内的数据生成方法
                    step = Step(v)
                    res = step.run()
                    params_dict[k] = list(res)
                else:
                    params_dict[k] = v

        if args:
            params_dict = list(args)
        return params_dict

    def param(self, **kwargs):
        '''
        把params数据中的每一组数据单独赋值给用例
          - param:
              a: 1
              b: 10
        :param kwargs:
        :return:
        '''
        self.get_context().set_param(kwargs)
        self.get_context().global_dict.update(kwargs)

    def run(self):
        '''
        每个步骤的执行
        - print: 1
        - if: $(a>b)
          true:
            - log: 1
          false:
            -log: 2
        :return:
        '''
        # todo: 文件与行号
        if 'method' not in self._dict:
            log.info(f"step: {self._dict}")
        else:
            log.info("step: method")

        for key, value in self._dict.items():
            # log.debug(f"{key}: {value}")
            # setup步骤不解析参数，因为里面的步骤还会被拆分执行，拆分后再做解析
            if key == 'while' or key == 'if':
                self._method_name = key
                self._params = {f'if_{str(k).lower()}': v for k, v in self._dict.items()}
                self._params_parse = False
                break
            elif key == 'setup':
                self._method_name = key
                self._params = value
                self._params_parse = False
            else:
                # 常规方法解析
                class_method = str(key).split('.')
                # random.random()
                if len(class_method) >= 2:
                    self._package_name = '.'.join(class_method[0:-2])
                    self._object_name = class_method[-2]
                    self._method_name = class_method[-1]
                # print()
                elif len(class_method) == 1:
                    self._method_name = class_method[0]
                else:
                    raise ValueError("please use class_name.method_name")

                self._params = value

                # log.debug(
                #     f"parse to {self._package_name}.{self._object_name}.{self._method_name}({repr(self._params)})")

        # log.debug(f"find {self._object_name}.{self._method_name}({repr(self._params)})")
        class_object = self.object_get()
        method_object = self.method_get(class_object)
        if method_object is not None:
            return self.method_run(method_object)
        else:
            log.error("method is None")
            raise ValueError("method is None")

    def get_param_dict(self):
        '''
        依次查找locals param data() globals
        :return:
        '''
        param_dict = globals()
        method_mapping = {
            'data': self.data,
        }
        param_dict.update(method_mapping)
        if self.get_context() is not None:
            param_dict.update(self.get_context().global_dict)
        else:
            pass
        param_dict.update(locals())
        return param_dict

    def update_params(self, data, param_dict):
        '''
        获取参数并进行模板替换，支持参数列表与命名参数

        :param data:
        :param param_dict:
        :return:
        '''

        def recursion(d):
            if isinstance(d, list):
                return [recursion(l) for l in d]
            elif isinstance(d, dict):
                return {k: recursion(v) for k, v in d.items()}
            elif isinstance(d, str):
                if d.startswith('$(') and d.endswith(')'):
                    return Utils.eval(d, param_dict)
                elif '${' in d:
                    return Utils.template(d, param_dict)
                else:
                    return d
            else:
                return d

        return recursion(data)

    def branch_hit(self, real, expect=True) -> bool:
        if real is not None and isinstance(real, str):
            real_parsed = self.update_params(real, self.get_param_dict())
            result = (str(real_parsed) == str(expect))
        else:
            result = True

        log.debug(f"{real} => {result}")
        return result

    def object_get(self):
        '''
        找变量或者找包
        :return:
        '''
        # log.debug(f'globals={globals().keys()}')
        if self._object_name in [[], '']:
            return self
        else:
            param_dict = self.get_param_dict()
            if self._object_name in param_dict and self._package_name == '':
                return param_dict[self._object_name]
            else:
                if self._package_name == '':
                    # random.random()
                    self._package_name = self._object_name
                else:
                    # sys.path.append()
                    # mtf.core.testcase.TestCase()
                    self._package_name = '.'.join([self._package_name, self._object_name])
                self._object_name = ''
                log.debug(f"first load {self._package_name}")
                # 动态导入某个包

                name_list = self._package_name.split('.')

                def find(index):
                    package_name = '.'.join(name_list[0:index + 1])
                    package_target = importlib.import_module(package_name)
                    importlib.invalidate_caches()
                    globals()[package_name] = package_target
                    if len(name_list) == index + 1:
                        return package_target
                    else:
                        object_name = name_list[index + 1]
                        if hasattr(package_target, object_name):
                            object_target = getattr(package_target, object_name)
                            if inspect.ismodule(object_target):
                                return find(index + 1)
                            else:
                                return object_target
                        else:
                            return find(index + 1)

                package_target = find(0)
                return package_target

    def method_get(self, class_object):
        '''
        找方法
        :param class_object:
        :return:
        '''
        # 方法名别名替换, 解决无法直接调用与关键词重名的方法
        if self._method_name in ['return', 'import', 'assert', 'if', 'while']:
            self._method_name = f"_{self._method_name}"

        log.debug(f"find {self._object_name}.{self._method_name}({repr(self._params)})")
        # 方法获取
        # todo: use 3rd lib
        if hasattr(class_object, self._method_name):
            return getattr(class_object, self._method_name)
        # 支持print等内置函数
        elif self._method_name in globals()['__builtins__']:
            return globals()['__builtins__'][self._method_name]
        # 查找page object方法
        elif self._method_name in self.get_context().store.class_pool.keys():
            return self.get_context().store.class_pool[self._method_name]
        elif self._method_name == "":
            return None
        else:
            raise ValueError(f"no such method {self._object_name}.{self._method_name}")

    def method_run(self, method_object):
        '''
        运行特定的方法，并设置参数
        :param method_object:
        :return:
        '''

        if self._params_parse:
            # 更新参数，更新表达式为具体的值
            param_dict = self.get_param_dict()
            # 更新所有的表达式
            params_new = self.update_params(self._params, param_dict)
        else:
            # if while setup特殊方法除外不需要解析参数，他们会独立解析
            params_new = self._params
        if isinstance(params_new, list):
            # method(*[])  = method()
            # method(1,2,3)
            return method_object(*params_new)
        elif isinstance(params_new, dict):
            if inspect.isbuiltin(method_object):
                pass
            else:
                # todo: method({}) 会出现一种特例，理论上需要判断参数个数再决定，inspect可以做到
                argspec = inspect.getfullargspec(method_object)
                # 如果一个方法有单个参数，而yaml传递的是一个词典，这个时候优化为把词典作为整个参数，不拆分
                if argspec.varkw is None and len(argspec.args) == 2:
                    return method_object(params_new)
                else:
                    # 多个参数的时候，先不优化
                    pass
            # method(a=1, b=2)
            return method_object(**params_new)
        else:
            # method(a)
            return method_object(params_new)

    def __str__(self):
        def recursion(d):
            if isinstance(d, list):
                return '...'
                # return [recursion(item) for item in d]
            elif isinstance(d, dict):
                return {k: recursion(v) for k, v in d.items()}
            else:
                return d

        return Utils.to_json_str(recursion(self.get_dict()), indent=None)
