from typing import List

from mtf.core.logger import log


class Node:
    def __init__(self, data):
        self.data = data
        self.children: List[Node] = []

    def travel(self, node=None, depth=1, root=True):
        if root:
            node = self
        if node is None:
            return

        yield node, depth
        depth += 1
        for child in node.children:
            yield from self.travel(child, depth, False)
        depth -= 1

    def show(self, path):
        log.info("")

        with open(path + ".wbs.puml", mode='w', encoding='utf-8') as f:
            f.write(self.wbs())

        with open(path + ".mindmap.puml", mode='w', encoding='utf-8') as f:
            f.write(self.mindmap())

    def wbs(self):
        content = []
        # content.append('@startmindmap')
        content.append('@startwbs')
        for node, depth in self.travel():
            content.append(
                f'{"*" * depth}{">" if node.data == True else ""}{"<" if node.data == False else ""} {node.data}')

        # content.append('@endmindmap')
        content.append('@endwbs')
        return '\n'.join(content)

    def mindmap(self):
        content = []
        content.append('@startmindmap')
        for node, depth in self.travel():
            content.append(f'{"*" * depth} {node.data}')

        content.append('@endmindmap')
        return '\n'.join(content)
