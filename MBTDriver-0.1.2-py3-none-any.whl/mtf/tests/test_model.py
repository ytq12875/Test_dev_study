from mtf.core.model import Node


def test_show():
    tree = Node(1)
    node2 = Node(2)
    node2.children.append(Node(3))
    tree.children.append(node2)

    node4 = Node(4)
    tree.children.append(node4)
    tree.show(__file__)
