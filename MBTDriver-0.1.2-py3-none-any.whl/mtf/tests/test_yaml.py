import yaml

from mtf.core.logger import log
from mtf.core.utils import Utils


def test_yaml():
    with open(Utils.get_current_dir(__file__) + "/test_yaml.yaml") as f:
        d = yaml.load(f.read())
        log.debug(d)


def test_data1():
    a = [1, 2, 3]
    b = [4, 5, 6]

    d = []
    for i in range(0, len(a)):
        x = [a[i], b[i]]
        d.append(x)

    print(d)


def test_switch():
    a = 1
    b = 2
    c = 1
    d = 1
    e = 1
    f = 1

    if a > b:
        pass
    elif c > d:
        pass
    elif e > f:
        pass
    else:
        pass
