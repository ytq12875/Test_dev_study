from csrmock.core.protocol.protocol_message import ProtocolMessage


class ProtocolSimple(ProtocolMessage):
    def encode_res(self):
        return self.res

    def decode_req(self, req):
        self.req = req

    def hit(self, req_real):
        if req_real == self.req_matcher:
            return self.encode_res()
        else:
            return None
