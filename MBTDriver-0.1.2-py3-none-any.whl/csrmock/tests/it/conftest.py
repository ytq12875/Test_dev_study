from multiprocessing.context import Process
from time import sleep

import pytest
from _pytest.fixtures import FixtureRequest

from csrmock.core.callback_server import CallBackServer
from csrmock.core.mitm.mitm_json import MitmJson
from csrmock.core.mitm.mitm_tcp import MitmTcp
from mtf.core.logger import log
from mtf.core.utils import Utils


@pytest.fixture(scope='module', autouse=True)
def start_server_in_module():
    log.debug('module setup')
    process_json = Utils.process(target=MitmJson.main)
    process_tcp = Utils.process(target=MitmTcp.main)

    server = CallBackServer()
    Utils.thread(
        target=server.start_server,
        args=(8008,)
    )

    while True:
        r = set()
        r.add(Utils.connect('127.0.0.1', 8001))
        r.add(Utils.connect('127.0.0.1', 8002))
        r.add(Utils.connect('127.0.0.1', 9102))
        r.add(Utils.connect('127.0.0.1', 8004))
        r.add(Utils.connect('127.0.0.1', 8008))
        log.debug(r)
        if r == {0}:
            break
        else:
            sleep(1)

    yield
    log.debug("teardown module")
    process_json.kill()
    process_json.join()
    process_tcp.kill()
    process_tcp.join()
    # log.debug(request.config.p)
    # p: Process=request.config.p
    # p.terminate()
    # log.debug('term')
    # p.join()
    # log.debug('join')
    # log.debug(p.exitcode)
