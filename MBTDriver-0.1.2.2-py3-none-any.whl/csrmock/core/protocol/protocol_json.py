from mitmproxy import http

from mtf.core.utils import Utils
from csrmock.core.protocol.protocol_message import ProtocolMessage


class ProtocolJson(ProtocolMessage):

    @classmethod
    def get_demo_res(cls) -> http.HTTPResponse:
        return http.HTTPResponse.make(
            200,  # (optional) status code
            Utils.to_json_str({'errcode': 1, 'msg': 'mock demo'}),  # (optional) content
            {"Content-Type": "application/json; charset=utf-8"}  # (optional) headers
        )

    @classmethod
    def get_demo_req(cls) -> http.HTTPRequest:
        return http.HTTPRequest.make(
            method='POST',
            url='https://ceshiren.com',
            content=Utils.to_json_str({'data': 'req demo'}),
            headers={"Content-Type": "application/json; charset=utf-8"}
        )

    def encode_res(self):
        return http.HTTPResponse.make(
            200,  # (optional) status code
            Utils.to_json_str(self.res),  # (optional) content
            {"Content-Type": "application/json; charset=utf-8"}  # (optional) headers
        )

    def decode_req(self, req_real: http.HTTPRequest):
        return req_real.data
