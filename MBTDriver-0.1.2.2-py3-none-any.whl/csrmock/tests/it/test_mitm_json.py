from multiprocessing.queues import Queue
from time import sleep

import requests

from csrmock.core.mitm.mitm_json import MitmJson
from csrmock.core.mock_client import MockClient
from multiprocessing import Process

from mtf.core.logger import log
from mtf.core.utils import Utils


class TestMitmJson:
    def setup_class(self):
        pass

    def test_main(self):
        # MitmJson.main('https://ceshiren.com:443')
        client = MockClient(url='http://127.0.0.1:8002')
        client.reset()
        client.mock('$..[?(@.method=="GET")]', {'a': 1})
        r = requests.get('http://127.0.0.1:8001/')
        assert r.json()['a'] == 1

        client = MockClient(url='http://127.0.0.1:8002')
        client.mock('$..[?(@.method=="POST")]', {'b': 2})
        r = requests.post('http://127.0.0.1:8001/')
        log.debug(r.json())
        assert r.json()['b'] == 2

    def test_main_config(self):
        # MitmJson.main('https://ceshiren.com:443')
        client = MockClient(url='http://127.0.0.1:8002')
        client.reset()
        client.mock(
            '$..[?(@.method=="GET")]',
            {'a': 1},
            config={
                'action': [{'eval': '1+2'}],
                'limit': -1
            }
        )
        r = requests.get('http://127.0.0.1:8001/')

        assert r.json()['a'] == 1
