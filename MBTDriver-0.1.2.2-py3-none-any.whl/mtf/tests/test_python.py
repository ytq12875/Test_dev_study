import importlib
import inspect

import pytest


@pytest.mark.parametrize('path', [
    'mtf.core.testcase.TestCase',
    'sys.path',
    'random.random',
    'random'
])
def test_find_module(path):
    name_list = path.split('.')

    def find(index):
        package_name = '.'.join(name_list[0:index + 1])
        package_target = importlib.import_module(package_name)
        if len(name_list) == index + 1:
            return package_target
        else:
            object_name = name_list[index + 1]
            if hasattr(package_target, object_name):
                object_target = getattr(package_target, object_name)
                if inspect.ismodule(object_target):
                    return find(index + 1)
                else:
                    return object_target
            else:
                return find(index + 1)

    print(find(0))
