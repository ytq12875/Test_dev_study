# -*- coding: utf-8 -*-
import re
from copy import copy

import jsonpath


class TextFile:
    """
    将 txt 结构化成 python 数据格式
    """

    def __init__(self):
        self._raw_datas = ""
        self._regulars = {}

    def __handle_log(self, data, regulars: list):
        result = []
        for regular in regulars:
            for expr in regular["pattern"]:
                find_results_iter = re.finditer(expr, data)
                if regular.get("sub"):
                    # 寻找切割符
                    pre_split_key = None
                    # 切割掉第一部分
                    count = 0
                    format_datas = data
                    split_key = next(find_results_iter)
                    while True:
                        split_datas = format_datas.split(split_key.group(), 1)
                        if pre_split_key is None:
                            # 第一次，不存
                            pre_split_key = split_key
                            continue
                        cur_dict = pre_split_key.groupdict()
                        pre_results = self.__handle_log(split_datas[0], regular['sub'])
                        for pre_result in pre_results:
                            # 如果存在 None 就删除
                            for key in list(pre_result.keys()):
                                if not pre_result.get(key):
                                    del pre_result[key]
                            cur_dict.update(pre_result)
                            result.append(cur_dict.copy())
                        pre_split_key = split_key
                        try:
                            format_datas = split_datas[1]
                            split_key = next(copy(find_results_iter))
                        except (StopIteration, IndexError):
                            if count == 1:
                                break
                            else:
                                # 最后一次，存
                                count += 1
                else:
                    return [i.groupdict() for i in find_results_iter]
        return result

    def parse(self, raw_datas, regular):
        """
        将 log 结构化
        :return:
        """
        self._regulars = regular
        format_data = self.__handle_log(raw_datas, self._regulars)
        self._format_data = self._update_data(format_data)
        return self._format_data

    def get_format_data(self):
        return self._format_data

    def read_by_jsonpath(self, jsonpath_expr):
        return jsonpath.jsonpath(self._format_data, jsonpath_expr)

    def _update_data(self, format_data):
        """
        对结构化后的数据进行二次处理
        :param data:
        :return:
        """
        return format_data