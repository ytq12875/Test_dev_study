from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mtf.core.context import Context


class ContextBase:
    _context: Context = None

    def __init__(self):
        pass

    def get_context(self) -> Context:
        return self._context

    def set_context(self, context):
        self._context = context
